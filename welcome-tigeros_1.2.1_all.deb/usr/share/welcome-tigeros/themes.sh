#!/usr/bin/env bash
#
#
# WELCOME PARA O TIGER OS
#
# Desenvolvido por eltonff 31/10/2020
# Com a ferramenta BigBashView
# Tecnologias utilizadas: bash, html, css, javascript e <3

icon_theme="$(xfconf-query -c xsettings -p /Net/IconThemeName)"
sys_theme="$(xfconf-query -c xsettings -p /Net/ThemeName)"

case $1 in
    mix)
        if [ $(grep -i 'amber' <<< $icon_theme) ]; then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Amber" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Orange-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Orange-Mix"
        elif [ $(grep -i 'green' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Green" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Green-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Green-Mix"
        elif [ $(grep -i 'gray' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Gray" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Grey-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Grey-Mix"
        elif [ $(grep -i 'red' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Red" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Red-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Red-Mix"
        elif [ $(grep -i 'purple' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Purple" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Purple-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Purple-Mix"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Blue-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Blue-Mix"
        fi

        ;;
    dark)
        if [ $(grep -i 'amber' <<< $icon_theme) ]; then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Amber" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Orange-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'green' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Green" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Green-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'gray' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Gray" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Grey-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'red' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Red" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Red-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'purple' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Purple" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Purple-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Blue-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        fi
        ;;

    light)
        if [ $(grep -i 'amber' <<< $icon_theme) ]; then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Amber-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Orange-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        elif [ $(grep -i 'green' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Green-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Green-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        elif [ $(grep -i 'gray' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Gray-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Grey-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        elif [ $(grep -i 'red' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Red-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Red-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        elif [ $(grep -i 'purple' <<< $icon_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Purple-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Purple-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Blue-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        fi
    ;;

    blue)
        if [ $(grep -i 'dark' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Blue-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'light' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Blue-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Blue-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Blue-Mix"
        fi
        ;;

    amber)
        if [ $(grep -i 'dark' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Amber" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Orange-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'light' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Amber-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Orange-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Amber" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Orange-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Orange-Mix"
        fi
        ;;

    gray)
        if [ $(grep -i 'dark' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Gray" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Grey-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'light' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Gray-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Grey-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Gray" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Grey-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Grey-Mix"
        fi
        ;;

    green)
        if [ $(grep -i 'dark' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Green" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Green-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'light' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Green-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Green-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Green" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Green-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Green-Mix"
        fi
        ;;

    purple)
        if [ $(grep -i 'dark' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Purple" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Purple-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'light' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Purple-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Purple-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Purple" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Purple-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Purple-Mix"
        fi
        ;;

    red)
        if [ $(grep -i 'dark' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Red" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Red-Dark" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Dark"
        elif [ $(grep -i 'light' <<< $sys_theme) ];then
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Red-Light" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Red-Light" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-XFWM4-Light"
        else
            xfconf-query -c xsettings -p /Net/IconThemeName -s "Obsidian-Red" &
            xfconf-query -c xsettings -p /Net/ThemeName -s "Tiger-Red-Mix" &
            xfconf-query -c xfwm4 -p /general/theme -s "Tiger-Red-Mix"
        fi
        ;;

    *) exit ;;
esac

exit
