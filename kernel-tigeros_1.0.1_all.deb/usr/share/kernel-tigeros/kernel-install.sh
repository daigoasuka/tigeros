#!/bin/bash

windowID="$(xwininfo -name "Configurações de Kernel" | head -n2 | tail -n1 | awk '{print $4}')"

[ "$(pidof zenity)" ] && zenity --warning --attach="$windowID" --width=350 --modal \
--text="Já existe outra instalação em andamento!\nAguarde a instalação concluir..." && exit

function installKernel(){
  export DEBIAN_FRONTEND="noninteractive"
  apt-get install "$1" "$2" -y && {
    update-initramfs -u
    update-grub
    zenity --info --width=350 --attach="$windowID" --modal \
    --text="O Kernel $3 ($1) foi instalado com sucesso! Reinicie o sistema para que as alterações tenham efeito."
  } || {
    zenity --error --width=350 --attach="$windowID" --modal \
    --text="Não foi possível concluir a instalação do Kernel $3 ($1)! Por favor, verifique e tente novamente!"
  }
}

header="${1/linux-image/linux-headers}"

installKernel "$1" "$header" "$2" | \
zenity --progress --no-cancel --width=350 --modal \
--attach="$windowID" --auto-close --pulsate \
--text="Instalando o Kernel $2, isso leva alguns minutos dependendo da sua conexão com a internet...\n\nPor favor, aguarde...\n"
