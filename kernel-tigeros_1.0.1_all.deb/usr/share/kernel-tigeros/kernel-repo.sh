#!/bin/bash

case $1 in
    xanmod )
        echo 'deb http://deb.xanmod.org releases main' | tee /etc/apt/sources.list.d/xanmod-kernel.list
        wget -qO - https://dl.xanmod.org/gpg.key | apt-key --keyring /etc/apt/trusted.gpg.d/xanmod-kernel.gpg add -
        apt update
        exit
    ;;
    liquorix)
        add-apt-repository ppa:damentz/liquorix -y
        exit
    ;;

    *) exit ;;
esac
